/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

 int main(){
     
     double x ;
         
         double ret;
       
         
         
         
         for(x=1;x<=100;x+=10){ret = log(x);printf("log(%lf) = %lf\n", x, ret);}           // log(x)     
         
        
         for(x=1;x<=100;x+=10)printf("%lf=%lf\t\n", x,x);                      // x
         
         for(x=1;x<=100;x+=10)printf("exp( %lf ) = %lf\n", x, exp(x));       // e raise to x
        
        for(x=1;x<=100;x+=10)printf("1.5^%lf=%lf  \n",x, pow(1.5, x));    // 3/2 raise to x
         
         for(x=1;x<=100;x+=10)printf(" %lf^3=%lf\t\n", x, pow(x,3));         // x raise to 3
         
         for(x=1;x<=100;x+=10)printf("2^%lf= %lf\t\n", x , pow(2,x));       // 2 raise to x
         
         for(x=1;x<=100;x+=10){ret = log(x);printf("%lf^1/2= %lf\t\n", ret, sqrt(ret));}   // underroot of log(x)
         
         for(x=1;x<=100;x+=10){ret = log(x);printf("1.41 ^ %lf= %lf\t\n", x, pow(1.41, ret));} // underroot of 2 raise to log(x)
         
         for(x=1;x<=100;x+=10){
            double v= x*pow(2,x);
            printf("%lf * %lf = %lf\t\n" , x , pow(2,x), v);
             
         }    // x *2^x 
         
         for(x=1;x<=100;x+=10){
         double r = 2*pow(2,x);
         printf("2^%.2lf = %.2lf\n" ,pow(2,x) , r);         // 2 raise to 2 raise x   i.e(2^2^x)
         }         
        
      
     
     return 0;
}

